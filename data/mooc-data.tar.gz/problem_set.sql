-- MySQL dump 10.13  Distrib 5.7.19, for osx10.12 (x86_64)
--
-- Host: 10.173.38.48    Database: core
-- ------------------------------------------------------
-- Server version	5.7.12-v1a-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='0422a2ae-2931-11e8-be69-fa163ee12619:1-386,
06128ad3-28df-11e8-b231-fa163eaa0f46:1-1080,
3362b822-81ff-11e7-9402-fa163e974eb3:1-34508857,
367c828c-81ff-11e7-84af-fa163e4541f9:1-11744077,
7f6e37a1-2f02-11e8-ab86-fa163e8daafb:1-65,
c75fa1a0-2de6-11e8-83e5-fa163ef683b4:1-38,
e60b3fca-070e-11e8-8652-fa163e378e63:1-13356217';

--
-- Table structure for table `problem_set`
--

DROP TABLE IF EXISTS `problem_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problem_set` (
  `id` bigint(20) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted` bit(1) NOT NULL,
  `description` text NOT NULL,
  `duration` bigint(20) NOT NULL,
  `end_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(255) NOT NULL,
  `problem_set_config` json NOT NULL,
  `share_code` varchar(255) DEFAULT NULL,
  `start_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_type` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `owner_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `oms_protected` tinyint(4) NOT NULL DEFAULT '0',
  `category_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_n8tbmqox8nkxvjexbrqudew72` (`share_code`),
  KEY `idx_product_id` (`deleted`,`product_id`),
  KEY `idx_type_product_id` (`deleted`,`type`,`product_id`),
  KEY `idx_owner_id_product_id` (`deleted`,`owner_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problem_set`
--
-- WHERE:  id = 904575737400999936

LOCK TABLES `problem_set` WRITE;
/*!40000 ALTER TABLE `problem_set` DISABLE KEYS */;
INSERT INTO `problem_set` VALUES (904575737400999936,'2017-09-04 05:23:56','\0','这是中M2017年秋季班（第5期）的C语言入门和进阶两门课的练习题目集。这里的题目的成绩不会计入MOOC课程成绩中，但是在MOOC的讨论区可以讨论这些题目。',15292800000000000,'2018-02-27 16:00:00','中M2017秋C入门和进阶练习集','{\"compilers\": [\"GCC\"], \"randomGenerationProblemSetConfig\": {\"shuffledAnswers\": true, \"shuffledProblems\": true, \"randomComposition\": true}, \"multipleChoiceMoreThanOneAnswerProblemScoringMethod\": \"METHOD2\"}','B9ED8BBE36F25895','2017-09-03 16:00:00',1,0,'2018-03-02 03:17:23',5056,2,0,958840902655139840);
/*!40000 ALTER TABLE `problem_set` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-29 19:02:14
